# NSFW Bot

NSFW Bot is an open-source discord bot that has nsfw commands running with the nekobot.xyz api.

## Commands :

- NSFW Commands 🔞 : `4k`, `anal`, `ass`, `boobs`, `hanal`, `hass`, `hboobs`, `hentai`, `hkitsune`, `hmidriff`, `hneko`, `holo`, `kemonomimi`, `neko`, `pgif`, `pussy`, `yaoi`
- Other Commands 🧷 : `help`, `stats`

## How to install ?

```bash
git clone https://github.com/Sayrix/NSFW-Bot
cd NSFW-Bot
npm i
```

## How to config ?

```json
//config.json
{
  "prefix": "your prefix",
  "token": "your token",
  "owners": ["OWNER ID"],
  "footer": "NSFW Bot • is.gd/nsfwbot",

  "msg": {
    "nsfwWarn": "You must use this command in an nsfw channel!",
    "loading": "Please wait...",
    "imageNotLoading": "Image not loading ? Click Here"
  }
}
```



## Many thanks to the people who will put a ⭐!
